export default /* glsl */ `
#ifdef USE_SPECULARMAP

	uniform sampler2D specularMap;

#endif
`;
