import { EXTENSIONS } from "./utils";

/**
 * Mesh Quantization Extension
 *
 * Specification: https://github.com/KhronosGroup/glTF/tree/master/extensions/2.0/Khronos/KHR_mesh_quantization
 */
 export class GLTFMeshQuantizationExtension {
	constructor() {
		this.name = EXTENSIONS.KHR_MESH_QUANTIZATION;
	}
}
