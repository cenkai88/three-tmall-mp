import { Light } from './Light.js';
import { PointLightShadow } from './PointLightShadow.js';

class PointLight extends Light {
  constructor(color, intensity, distance = 0, decay = 1) {
    super(color, intensity);

    this.type = 'PointLight';

    this.distance = distance;
    this.decay = decay; // for physically correct lights, should be 2.

    this.shadow = new PointLightShadow();
  }

  get power() {
    // compute the light's luminous power (in lumens) from its intensity (in candela)
    // for an isotropic light source, luminous power (lm) = 4 π luminous intensity (cd)
    return this.intensity * 4 * Math.PI;
  }

  set power(power) {
    // set the light's intensity (in candela) from the desired luminous power (in lumens)
    this.intensity = power / (4 * Math.PI);
  }

  dispose() {
    this.shadow.dispose();
  }

  copy(source) {
    super.copy(source);

    this.distance = source.distance;
    this.decay = source.decay;

    this.shadow = source.shadow.clone();

    return this;
  }
}

PointLight.prototype.isPointLight = true;

export { PointLight };
